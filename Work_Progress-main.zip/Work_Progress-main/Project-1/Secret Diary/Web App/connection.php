<?php

    $link = mysqli_connect("shareddb1b.hosting.stackcp.net", "cl29-secretdi", "D-fnT^Hbz", "cl29-secretdi");
        
        if (mysqli_connect_error()) {
            
            die ("Database Connection Error");
            
        }

?>